# Refund a Payment


## Prerequisites

To refund a payment, an Authorization must have been completed.

## Steps

Add a Refund transaction to the Klarna payment with the amount you wish to refund. Partial refunds are supported
