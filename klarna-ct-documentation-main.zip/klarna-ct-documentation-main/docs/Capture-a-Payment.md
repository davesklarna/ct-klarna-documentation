# Capture a Payment


## Prerequisites

To capture a payment, an Authorization must have been completed.

## Steps

Add a Charge transaction to the Klarna payment with the amount you wish to capture. Partial captures are supported
